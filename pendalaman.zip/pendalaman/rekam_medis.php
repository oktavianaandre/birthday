<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Klinik Apotik Bunda Aliya</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }

        header {
            background: #333;
            color: #fff;
            padding: 1rem 0;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        .report-links {
            margin: 20px 0;
        }

        .report-links a {
            background: #333;
            color: #fff;
            padding: 1rem 2rem;
            text-decoration: none;
            border-radius: 8px;
            font-size: 1.2rem;
        }

        .report-links a:hover {
            background: #555;
        }

        .button-container {
            margin-top: 1rem;
            text-align: center;
        }

        .button-container a {
            background: #007bff;
            color: #fff;
            padding: 0.75rem 0.5rem;
            border-radius: 5px;
            font-size: 1rem;
            text-decoration: none;
        }

        .button-container a:hover {
            background: #0056b3;
        }

        .add-new-container {
            text-align: left;
            margin: 20px 0;
        }

        .add-new-container a {
            background: #28a745;
            color: #fff;
            padding: 0.75rem 1rem;
            text-decoration: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
        }

        .add-new-container a:hover {
            background: #218838;
        }

        .action-buttons a {
            margin: 0 5px;
            padding: 0.5rem 1rem;
            border-radius: 5px;
            font-size: 0.9rem;
            text-decoration: none;
        }

        .edit-button {
            background: #007bff;
            color: #fff;
        }

        .edit-button:hover {
            background: #0056b3;
        }

        .delete-button {
            background: #dc3545;
            color: #fff;
        }

        .delete-button:hover {
            background: #c82333;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Laporan Klinik Apotik Bunda Aliya</h1>
        </header>
        <main>

            <!-- Tombol Add New -->
            <div class="add-new-container">
                <a href="form_rekam_medis.php">Add New</a>
            </div>

            <h2>Daftar Rekam Medis</h2>
            <?php
            include 'db.php';

            function calculateAge($birthDate) {
                $birthDate = new DateTime($birthDate);
                $currentDate = new DateTime();
                $interval = $birthDate->diff($currentDate);
                return $interval->y;
            }

            $sql = "SELECT
                        t.No_Transaksi,
                        p.Kode_Peserta,
                        p.Nama_Peserta,
                        p.Tanggal_Lahir,
                        TIMESTAMPDIFF(YEAR, p.Tanggal_Lahir, CURDATE()) AS Usia,
                        p.Jenis_Kelamin,
                        t.Keluhan,
                        poli.Nama_Poli,
                        bidan.Nama_Bidan,
                        t.Biaya_Admin
                    FROM
                        TrekamMedis t
                    JOIN
                        Peserta p ON t.Kode_Peserta = p.Kode_Peserta
                    JOIN
                        Poli poli ON t.Kode_Poli = poli.Kode_Poli
                    JOIN
                        Bidan bidan ON t.Kode_Bidan = bidan.Kode_Bidan";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo '<table>';
                echo '<tr><th>No Transaksi</th><th>Kode Peserta</th><th>Nama Peserta</th><th>Usia</th><th>Jenis Kelamin</th><th>Keluhan</th><th>Nama Poli</th><th>Nama Bidan</th><th>Biaya Admin</th><th>Aksi</th></tr>';
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['No_Transaksi'] . '</td>';
                    echo '<td>' . $row['Kode_Peserta'] . '</td>';
                    echo '<td>' . $row['Nama_Peserta'] . '</td>';
                    echo '<td>' . $row['Usia'] . '</td>';
                    echo '<td>' . $row['Jenis_Kelamin'] . '</td>';
                    echo '<td>' . $row['Keluhan'] . '</td>';
                    echo '<td>' . $row['Nama_Poli'] . '</td>';
                    echo '<td>' . $row['Nama_Bidan'] . '</td>';
                    echo '<td>' .'Rp.- '. $row['Biaya_Admin'] . '</td>';
                    echo '<td class="action-buttons">';
                    echo '<a href="edit_rekam_medis.php?no_transaksi=' . $row['No_Transaksi'] . '" class="edit-button" >Edit</a>';
                    echo '<a href="#" data-no-transaksi="' . $row['No_Transaksi'] . '" class="delete-button">Delete</a>';
                    echo '</td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                echo "No records found.";
            }

            $conn->close();
            ?>
        </main>
    </div>

    <div class="button-container">
        <a href="dashboard.php">Kembali ke Dashboard</a>
    </div>

    <script>
    // Fungsi untuk menampilkan konfirmasi hapus
    function confirmDelete(noTransaksi) {
        // Tampilkan dialog konfirmasi
        Swal.fire({
            title: 'Anda yakin?',
            text: `Apakah Anda ingin menghapus transaksi dengan No Transaksi ${noTransaksi}?`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Hapus',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                // Kirim permintaan penghapusan ke server
                fetch(`delete_rekam_medis.php?no_transaksi=${noTransaksi}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Menampilkan notifikasi sukses
                            Swal.fire({
                                title: 'Dihapus!',
                                text: 'Item telah berhasil dihapus.',
                                icon: 'success',
                                confirmButtonColor: '#3085d6',
                                confirmButtonText: 'OK'
                            }).then(() => {
                                // Memuat ulang halaman atau menghapus baris yang dihapus
                                location.reload(); // Memuat ulang halaman
                            });
                        } else {
                            // Menampilkan notifikasi gagal
                            Swal.fire({
                                title: 'Gagal!',
                                text: data.message,
                                icon: 'error',
                                confirmButtonColor: '#3085d6',
                                confirmButtonText: 'OK'
                            });
                        }
                    })
                    .catch(error => {
                        // Menampilkan notifikasi jika ada kesalahan
                        Swal.fire({
                            title: 'Terjadi Kesalahan!',
                            text: 'Tidak dapat menghapus item. Silakan coba lagi.',
                            icon: 'error',
                            confirmButtonColor: '#3085d6',
                            confirmButtonText: 'OK'
                        });
                    });
            }
        });
    }

        // Menambahkan event listener untuk tombol delete
        document.querySelector('table').addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('delete-button')) {
                e.preventDefault(); // Mencegah navigasi default
                const noTransaksi = e.target.getAttribute('data-no-transaksi');
                confirmDelete(noTransaksi);
            }
        });
    </script>

</body>
</html>
