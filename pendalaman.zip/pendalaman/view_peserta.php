<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Peserta Klinik Apotik Bunda Aliya</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }

        header {
            background: #333;
            color: #fff;
            padding: 1rem 0;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 30px 0;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 5px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        .button-container {
            margin-top: 1rem;
            text-align: center;
        }

        .button-container a {
            background: #007bff;
            color: #fff;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 4px;
            font-size: 1rem;
        }

        .button-container a:hover {
            background: #0056b3;
        }

        .action-buttons a {
            margin: 0 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            text-decoration: none;
            color: #fff;
            font-size: 0.9rem;
        }

        .edit-button {
            background: #28a745;
        }

        .edit-button:hover {
            background: #218838;
        }

        .delete-button {
            background: #dc3545;
        }

        .delete-button:hover {
            background: #c82333;
        }
        .button-container a:hover {
            background: #0056b3;
        }

        .add-new-container {
            text-align: left;
            margin: 20px 0;
        }

        .add-new-container a {
            background: #28a745;
            color: #fff;
            padding: 0.75rem 1rem;
            text-decoration: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Daftar Peserta Klinik Apotik Bunda Aliya</h1>
        </header>

        <div class="add-new-container">
                <a href="form_pasien.php">Add New</a>
        </div>
        <main>
            <?php
            include 'db.php';

            $sql = "SELECT * FROM Peserta";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo '<table>';
                echo '<tr><th>Kode Peserta</th><th>Nama Peserta</th><th>Tanggal Lahir</th><th>Jenis Kelamin</th><th>Alamat</th><th>Telepon</th><th>Email</th><th>Aksi</th></tr>';
                while ($row = $result->fetch_assoc()) {
                    // Calculate age
                    $tanggal_lahir = new DateTime($row['Tanggal_Lahir']);
                    $today = new DateTime('today');
                    $age = $today->diff($tanggal_lahir)->y;

                    echo '<tr>';
                    echo '<td>' . $row['Kode_Peserta'] . '</td>';
                    echo '<td>' . $row['Nama_Peserta'] . '</td>';
                    echo '<td>' . $row['Tanggal_Lahir'] . ' (' . $age . ' tahun)</td>';
                    echo '<td>' . $row['Jenis_Kelamin'] . '</td>';
                    echo '<td>' . $row['Alamat'] . '</td>';
                    echo '<td>' . $row['Telepon'] . '</td>';
                    echo '<td>' . $row['Email'] . '</td>';
                    echo '<td class="action-buttons">';
                    echo '<a href="edit_peserta.php?kode=' . $row['Kode_Peserta'] . '" class="edit-button">Edit</a>';
                    echo '<a href="delete_peserta.php?kode=' . $row['Kode_Peserta'] . '" class="delete-button" onclick="return confirm(\'Are you sure you want to delete this record?\')">Delete</a>';
                    echo '</td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                echo "<p>No records found.</p>";
            }

            $conn->close();
            ?>
        </main>
    </div>
      <div class="button-container">
       <a href="dashboard.php">Kembali ke Dashboard</a>
      </div>
</body>
</html>
