<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_peserta = $_POST['nama_peserta'];
    $tanggal_lahir_hari = $_POST['tanggal_lahir_hari'];
    $tanggal_lahir_bulan = $_POST['tanggal_lahir_bulan'];
    $tanggal_lahir_tahun = $_POST['tanggal_lahir_tahun'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    $email = $_POST['email'];

    // Format tanggal menjadi YYYY-MM-DD
    $tanggal_lahir = $tanggal_lahir_tahun . '-' . str_pad($tanggal_lahir_bulan, 2, '0', STR_PAD_LEFT) . '-' . str_pad($tanggal_lahir_hari, 2, '0', STR_PAD_LEFT);

    // Generate Kode_Peserta
    $result = $conn->query("SELECT MAX(Kode_Peserta) AS last_code FROM Peserta");
    $row = $result->fetch_assoc();
    $last_code = $row['last_code'];
    $last_number = (int) substr($last_code, 3); // Extract the number part after 'SP-'
    $new_number = str_pad($last_number + 1, 3, '0', STR_PAD_LEFT); // Increment and pad with zeros
    $kode_peserta = "SP-" . $new_number;

    // Query INSERT dengan Kode_Peserta yang dihasilkan
    $sql = "INSERT INTO Peserta (Kode_Peserta, Nama_Peserta, Tanggal_Lahir, Jenis_Kelamin, Alamat, Telepon, Email)
            VALUES ('$kode_peserta', '$nama_peserta', '$tanggal_lahir', '$jenis_kelamin', '$alamat', '$telepon', '$email')";

    if ($conn->query($sql) === TRUE) {
        header("Location: view_peserta.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Peserta</title>
    <style>
    /* Form Styles */
    form {
        background: #fff;
        padding: 2rem;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin: 2rem auto;
        width: 50%;
    }

    form input[type="text"],
    form input[type="email"],
    form input[type="number"],
    form select,
    form textarea {
        width: calc(100% - 2rem);
        padding: 0.5rem;
        margin-bottom: 1rem;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 1rem;
    }

    form input[type="submit"] {
        background: #333;
        color: #fff;
        border: none;
        padding: 0.75rem;
        border-radius: 4px;
        font-size: 1.2rem;
        cursor: pointer;
        width: 100%;
    }

    form input[type="submit"]:hover {
        background: #555;
    }

    .button-container {
        margin-top: 1rem;
        text-align: center;
    }

    .button-container button {
        background: #007bff;
        color: #fff;
        padding: 0.75rem 1.5rem;
        border-radius: 4px;
        font-size: 1rem;
        cursor: pointer;
        border: none;
    }

    /* Layout for Tanggal Lahir */
    .tanggal-lahir-container {
        display: flex;
        gap: 0.5rem;
        margin-bottom: 1rem;
    }

    .tanggal-lahir-container select,
    .tanggal-lahir-container input[type="number"] {
        flex: 1;
        padding: 0.5rem;
        border: 1px solid #ddd;
        border-radius: 4px;
    }
</style>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <form id="pesertaForm" method="post" action="form_pasien.php">
        <label for="nama_peserta">Nama Peserta:</label>
        <input type="text" name="nama_peserta" id="nama_peserta" required><br>

        <label for="tanggal_lahir">Tanggal Lahir:</label>
        <div class="tanggal-lahir-container">
            <select name="tanggal_lahir_hari" id="tanggal_lahir_hari" required>
                <?php
                for ($i = 1; $i <= 31; $i++) {
                    echo "<option value=\"$i\">" . str_pad($i, 2, '0', STR_PAD_LEFT) . "</option>";
                }
                ?>
            </select>
            <select name="tanggal_lahir_bulan" id="tanggal_lahir_bulan" required>
                <?php
                $bulan = [
                    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April',
                    '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus',
                    '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
                ];
                foreach ($bulan as $key => $value) {
                    echo "<option value=\"$key\">$value</option>";
                }
                ?>
            </select>
            <input type="number" name="tanggal_lahir_tahun" id="tanggal_lahir_tahun" placeholder="Tahun" min="1900" max="<?php echo date('Y'); ?>" required>
        </div>

        <label for="jenis_kelamin">Jenis Kelamin:</label>
        <select name="jenis_kelamin" id="jenis_kelamin" required>
            <option value="Laki-Laki">Laki-Laki</option>
            <option value="Perempuan">Perempuan</option>
        </select><br>

        <label for="alamat">Alamat:</label>
        <textarea name="alamat" id="alamat" required></textarea><br>

        <label for="telepon">Telepon:</label>
        <input type="text" name="telepon" id="telepon" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required><br>

        <input type="submit" value="Tambah Peserta">

        <div class="button-container">
            <a href="view_peserta.php">
                <button type="button">Kembali</button>
            </a>
        </div>
    </form>

    <script>
        // Add an event listener to handle form submission
        document.getElementById('pesertaForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission

            // Create a FormData object to send form data
            var formData = new FormData(this);

            // Use fetch to send form data to the server
            fetch('form_pasien.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                // Show SweetAlert2 success message
                Swal.fire({
                    title: 'Success!',
                    text: 'Data peserta berhasil ditambahkan.',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(() => {
                        window.location.href = 'view_peserta.php';
                });
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    </script>
</body>  
</html>
