<?php
include 'db.php';

if (isset($_GET['no_transaksi'])) {
    $no_transaksi = $_GET['no_transaksi'];
    $sql = "SELECT * FROM TrekamMedis WHERE No_Transaksi = '$no_transaksi'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
} else {
    echo "No transaction number provided.";
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $no_transaksi = $_POST['no_transaksi'];
    $kode_peserta = $_POST['kode_peserta'];
    $kode_bidan = $_POST['kode_bidan'];
    $kode_poli = $_POST['kode_poli'];
    $hari = $_POST['tanggal_berobat_hari'];
    $bulan = $_POST['tanggal_berobat_bulan'];
    $tahun = $_POST['tanggal_berobat_tahun'];
    $keluhan = $_POST['keluhan'];
    $biaya_admin = $_POST['biaya_admin'];
    $tgl_berobat = "$tahun-$bulan-$hari";

    $sql = "UPDATE TrekamMedis SET 
            Kode_Peserta = '$kode_peserta', 
            Kode_Bidan = '$kode_bidan', 
            Kode_Poli = '$kode_poli', 
            Tgl_Berobat = '$tgl_berobat', 
            Keluhan = '$keluhan', 
            Biaya_Admin = '$biaya_admin' 
            WHERE No_Transaksi = '$no_transaksi'";

    if ($conn->query($sql) === TRUE) {
        header("Location: rekam_medis.php");
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Rekam Medis</title>
    <style>
        /* Form Styles */
        form {
            background: #fff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 2rem auto;
            width: 50%;
        }

        form input[type="text"],
        form input[type="number"],
        form select,
        form textarea {
            width: calc(100% - 2rem);
            padding: 0.5rem;
            margin-bottom: 1rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        form input[type="submit"] {
            background: #333;
            color: #fff;
            border: none;
            padding: 0.75rem;
            border-radius: 4px;
            font-size: 1.2rem;
            cursor: pointer;
            width: 100%;
        }

        form input[type="submit"]:hover {
            background: #555;
        }

        .button-container {
            margin-top: 1rem;
            text-align: center;
        }

        .button-container a {
            background: #007bff;
            color: #fff;
            padding: 0.75rem 1.5rem;
            border-radius: 4px;
            font-size: 1rem;
            text-decoration: none;
        }

        .button-container a:hover {
            background: #0056b3;
        }

        .tanggal-lahir-container {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .tanggal-lahir-container select,
        .tanggal-lahir-container input[type="number"] {
            flex: 1;
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
    </style>
</head>
<body>
    <center><h2>Edit Rekam Medis</h2></center>
    <form method="post">
        <input type="hidden" name="no_transaksi" value="<?php echo $row['No_Transaksi']; ?>">

        Pasien:
        <select name="kode_peserta" required>
            <?php
            $result = $conn->query("SELECT * FROM Peserta");
            while ($peserta = $result->fetch_assoc()) {
                echo "<option value=\"" . $peserta['Kode_Peserta'] . "\"" . ($peserta['Kode_Peserta'] == $row['Kode_Peserta'] ? " selected" : "") . ">" . $peserta['Nama_Peserta'] . "</option>";
            }
            ?>
        </select><br>
        
        Dokter:
        <select name="kode_bidan" required>
            <?php
            $result = $conn->query("SELECT * FROM Bidan");
            while ($bidan = $result->fetch_assoc()) {
                echo "<option value=\"" . $bidan['Kode_Bidan'] . "\"" . ($bidan['Kode_Bidan'] == $row['Kode_Bidan'] ? " selected" : "") . ">" . $bidan['Nama_Bidan'] . "</option>";
            }
            ?>
        </select><br>
        
        Poli:
        <select name="kode_poli" required>
            <?php
            $result = $conn->query("SELECT * FROM Poli");
            while ($poli = $result->fetch_assoc()) {
                echo "<option value=\"" . $poli['Kode_Poli'] . "\"" . ($poli['Kode_Poli'] == $row['Kode_Poli'] ? " selected" : "") . ">" . $poli['Nama_Poli'] . "</option>";
            }
            ?>
        </select><br>
        
        Tanggal Berobat:
        <div class="tanggal-lahir-container">
            <select name="tanggal_berobat_hari" required>
                <?php
                $hari = date('d', strtotime($row['Tgl_Berobat']));
                for ($i = 1; $i <= 31; $i++) {
                    echo "<option value=\"" . str_pad($i, 2, '0', STR_PAD_LEFT) . "\"" . ($hari == str_pad($i, 2, '0', STR_PAD_LEFT) ? " selected" : "") . ">" . str_pad($i, 2, '0', STR_PAD_LEFT) . "</option>";
                }
                ?>
            </select>
            <select name="tanggal_berobat_bulan" required>
                <?php
                $bulan = date('m', strtotime($row['Tgl_Berobat']));
                $bulan_names = [
                    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April',
                    '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus',
                    '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
                ];
                foreach ($bulan_names as $key => $value) {
                    echo "<option value=\"$key\"" . ($bulan == $key ? " selected" : "") . ">$value</option>";
                }
                ?>
            </select>
            <input type="number" name="tanggal_berobat_tahun" value="<?php echo date('Y', strtotime($row['Tgl_Berobat'])); ?>" required><br>
        </div>
        
        Keluhan:
        <textarea name="keluhan" required><?php echo $row['Keluhan']; ?></textarea><br>
        
        Biaya Admin:
        <input type="number" name="biaya_admin" value="<?php echo $row['Biaya_Admin']; ?>" required><br>

        <input type="submit" value="Update">
        <div class="button-container">
            
        <a href="rekam_medis.php">
            Kembali
        </a>
    </div>
    </form>
</body>
</html>
