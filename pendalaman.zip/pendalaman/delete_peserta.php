<?php
// Include database connection file
include 'db.php';

// Check if the 'kode' parameter is set in the URL
if (isset($_GET['kode'])) {
    // Get the 'kode' parameter value
    $kode_peserta = $_GET['kode'];

    // Prepare the SQL statement to delete the record
    $sql = "DELETE FROM Peserta WHERE Kode_Peserta = ?";

    // Initialize a prepared statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind the 'kode_peserta' parameter to the SQL query
        $stmt->bind_param("s", $kode_peserta);

        // Execute the prepared statement
        if ($stmt->execute()) {
            // Record deleted successfully
            header("Location: view_peserta.php?status=success");
        } else {
            // Error occurred during deletion
            echo "Error: " . $stmt->error;
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        // Error occurred during statement preparation
        echo "Error: " . $conn->error;
    }
} else {
    // 'kode' parameter is not set
    echo "Error: Kode Peserta not specified.";
}

// Close the database connection
$conn->close();
?>
