<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_poli = $_POST['nama_poli'];

    $sql = "INSERT INTO Poli (Nama_Poli)
            VALUES ('$nama_poli')";

    if ($conn->query($sql) === TRUE) {
        echo "Data poli berhasil ditambahkan.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        /* Form Styles */
        form {
            background: #fff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 2rem auto;
            width: 50%;
        }

        form input[type="text"],
        form select,
        form textarea {
            width: calc(100% - 2rem);
            padding: 0.5rem;
            margin-bottom: 1rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        form input[type="submit"] {
            background: #333;
            color: #fff;
            border: none;
            padding: 0.75rem;
            border-radius: 4px;
            font-size: 1.2rem;
            cursor: pointer;
            width: 100%;
        }

        form input[type="submit"]:hover {
            background: #555;
        }

        .button-container {
            margin-top: 1rem;
            text-align: center;
        }

        .button-container button {
            background: #007bff;
            color: #fff;
            padding: 0.75rem 1.5rem;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            border: none;
        }
    </style>
</head>
<body>
<form method="post" action="form_poli.php">
    Nama Poli: <input type="text" name="nama_poli" required><br>
    <input type="submit" value="Tambah Poli">
    <div class="button-container">
        <a href="dashboard.php">
            <button type="button">Kembali ke Dashboard</button>
        </a>
    </div>
</form>
</body>
</html>

