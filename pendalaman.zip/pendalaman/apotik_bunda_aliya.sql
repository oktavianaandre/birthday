-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Agu 2024 pada 10.48
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apotik_bunda_aliya`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bidan`
--

CREATE TABLE `bidan` (
  `Kode_Bidan` int(11) NOT NULL,
  `Nama_Bidan` varchar(100) DEFAULT NULL,
  `Kode_Poli` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `bidan`
--

INSERT INTO `bidan` (`Kode_Bidan`, `Nama_Bidan`, `Kode_Poli`) VALUES
(1, 'Lili', 1),
(2, 'Aminah', 1),
(3, 'Nazwa', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `peserta`
--

CREATE TABLE `peserta` (
  `Kode_Peserta` varchar(10) NOT NULL,
  `Nama_Peserta` varchar(100) DEFAULT NULL,
  `Tanggal_Lahir` date DEFAULT NULL,
  `Jenis_Kelamin` enum('Laki-Laki','Perempuan') DEFAULT NULL,
  `Alamat` varchar(200) DEFAULT NULL,
  `Telepon` varchar(15) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `peserta`
--

INSERT INTO `peserta` (`Kode_Peserta`, `Nama_Peserta`, `Tanggal_Lahir`, `Jenis_Kelamin`, `Alamat`, `Telepon`, `Email`) VALUES
('SP-001', 'Raynor', '2003-11-01', 'Laki-Laki', 'JL.KASUARI IX', '081211141134', 'rickynelson028@gmail.com'),
('SP-002', 'Didi', '2001-11-01', 'Laki-Laki', 'Jl.Kasuari', '081211141134', 'rickynelson028@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `poli`
--

CREATE TABLE `poli` (
  `Kode_Poli` int(11) NOT NULL,
  `Nama_Poli` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `poli`
--

INSERT INTO `poli` (`Kode_Poli`, `Nama_Poli`) VALUES
(1, 'anak'),
(2, 'anestasi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `trekammedis`
--

CREATE TABLE `trekammedis` (
  `No_Transaksi` varchar(10) NOT NULL,
  `Kode_Peserta` varchar(10) DEFAULT NULL,
  `Kode_Bidan` int(11) DEFAULT NULL,
  `Kode_Poli` int(11) DEFAULT NULL,
  `Tgl_Berobat` date DEFAULT NULL,
  `Keluhan` text DEFAULT NULL,
  `Biaya_Admin` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `trekammedis`
--

INSERT INTO `trekammedis` (`No_Transaksi`, `Kode_Peserta`, `Kode_Bidan`, `Kode_Poli`, `Tgl_Berobat`, `Keluhan`, `Biaya_Admin`) VALUES
('TRX001', 'SP-001', 1, 1, '2023-07-01', 'Sakit Gigi', '2000000.00'),
('TRX002', 'SP-001', 1, 1, '2012-09-07', 'Sakit Kepala', '20000000.00'),
('TRX003', 'SP-001', 3, 2, '2012-11-01', 'Sakit Pinggang', '1000000.00');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bidan`
--
ALTER TABLE `bidan`
  ADD PRIMARY KEY (`Kode_Bidan`);

--
-- Indeks untuk tabel `peserta`
--
ALTER TABLE `peserta`
  ADD PRIMARY KEY (`Kode_Peserta`);

--
-- Indeks untuk tabel `poli`
--
ALTER TABLE `poli`
  ADD PRIMARY KEY (`Kode_Poli`);

--
-- Indeks untuk tabel `trekammedis`
--
ALTER TABLE `trekammedis`
  ADD PRIMARY KEY (`No_Transaksi`),
  ADD KEY `Kode_Peserta` (`Kode_Peserta`),
  ADD KEY `Kode_Bidan` (`Kode_Bidan`),
  ADD KEY `Kode_Poli` (`Kode_Poli`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `bidan`
--
ALTER TABLE `bidan`
  MODIFY `Kode_Bidan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `poli`
--
ALTER TABLE `poli`
  MODIFY `Kode_Poli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `trekammedis`
--
ALTER TABLE `trekammedis`
  ADD CONSTRAINT `trekammedis_ibfk_1` FOREIGN KEY (`Kode_Peserta`) REFERENCES `peserta` (`Kode_Peserta`),
  ADD CONSTRAINT `trekammedis_ibfk_2` FOREIGN KEY (`Kode_Bidan`) REFERENCES `bidan` (`Kode_Bidan`),
  ADD CONSTRAINT `trekammedis_ibfk_3` FOREIGN KEY (`Kode_Poli`) REFERENCES `poli` (`Kode_Poli`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
