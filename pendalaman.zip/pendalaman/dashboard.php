<?php
// Query untuk menghitung jumlah peserta
include 'db.php';

$sql = "SELECT * FROM Peserta";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $peserta = $result->num_rows;
} else {
    $peserta = 0;
}

// Query untuk menghitung jumlah dokter
$sql = "SELECT * FROM Bidan";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $bidan = $result->num_rows;
} else {
    $bidan = 0;
}

// Query untuk menghitung jumlah poli
$sql = "SELECT * FROM Poli";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $poli = $result->num_rows;
} else {
    $poli = 0;
}

// Tutup koneksi
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="bootstrap\css\bootstrap.css">
	<link rel="stylesheet" href="bootstrap\css\bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Dashboard Klinik Apotik Bunda Aliya</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            display: flex;
            transition: margin-left 0.3s;
        }

        .sidebar {
            width: 250px;
            background: #333;
            color: #fff;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            padding: 1rem;
            transition: transform 0.3s;
            transform: translateX(0);
        }

        .sidebar.hidden {
            transform: translateX(-100%);
        }

        .sidebar h1 {
            font-size: 1.5rem;
            margin-bottom: 9rem; /* Menambahkan jarak bawah */
        }

        .sidebar a {
            display: block;
            color: #fff;
            padding: 1rem;
            text-decoration: none;
            border-radius: 8px;
            margin-bottom: 1rem; /* Menambahkan margin bawah pada tautan */
        }
        .sidebar a:hover {
            background: #555;
        }

        .content header {
            background: #333;
            color: #fff;
            padding: 1rem 0;
            text-align: center;
            margin-bottom: 2rem;
            position: fixed; /* Menetapkan posisi tetap untuk header */
            top: 0;          /* Menempatkan di bagian atas */
            left: 0;         /* Menempatkan di sisi kiri */
            width: 100%;     /* Lebar penuh */
            z-index: 1000;   /* Pastikan header berada di atas konten lainnya */
        }

        /* Tambahkan padding atas pada konten untuk menghindari header yang menutupi konten */
        .content {
            margin-left: 250px;
            padding-top: 80px; /* Tambahkan padding atas sesuai dengan tinggi header */
            width: calc(100% - 250px);
            transition: margin-left 0.3s;
        }

        .content.expanded {
            margin-left: 0;
            width: 100%;
            padding-top: 80px; /* Tambahkan padding atas sesuai dengan tinggi header */
        }


        .overview {
            display: flex;
            justify-content: space-around;
            margin-bottom: 1rem;
        }

        .card {
            background: #fff;
            padding: 1rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 30%;
            margin-top:20px;
        }

        .card h2 {
            margin: 0;
        }

        .card p {
            font-size: 2rem;
            margin: 0.5rem 0;
        }

        .toggle-btn {
            position: fixed;
            top: 45px;
            left: 0; /* Sesuaikan posisi awal dengan sidebar */
            background: #fff;
            color: #333;
            border: none;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            cursor: pointer;
            z-index: 1000;
            transform: translateY(-50%);
            transition: left 0.3s; /* Animasi untuk memindahkan tombol */
        }

        .toggle-btn:hover {
            background: #555;
        }

        .sidebar.hidden ~ .toggle-btn {
            left: 0; /* Ketika sidebar disembunyikan, tombol pindah ke tepi kiri */
        }
        .container{
            height: 100px;
        }
        
        .tp{
            background-color: rgba(0, 0, 0, 0.5);
            border-radius: 8px;
        }

        .carousel-control-prev, .carousel-control-next {
      background-color: #007bff; /* Warna latar belakang biru cerah */
      border-radius: 50%; /* Membuat tombol bulat */
      width: 50px; /* Lebar tombol */
      height: 50px; /* Tinggi tombol */
      display: flex;
      align-items: center;
      justify-content: center;
      border: 2px solid #0056b3; /* Border biru lebih gelap untuk kontras */
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Efek bayangan untuk kedalaman */
      transition: background-color 0.3s ease, transform 0.3s ease;
    }
    .carousel-control-prev, .carousel-control-next {
      background-color: #007bff; /* Warna latar belakang biru cerah */
      border-radius: 5px; /* Sudut membulat */
      width: 50px; /* Lebar tombol */
      height: 40px; /* Tinggi tombol */
      display: flex;
      align-items: center;
      justify-content: center;
      border: 2px solid #0056b3; /* Border biru lebih gelap untuk kontras */
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Efek bayangan untuk kedalaman */
      transition: background-color 0.3s ease, transform 0.3s ease;
      text-align: center;
      margin-top: 300px;
    }

    .carousel-control-prev-icon, .carousel-control-next-icon {
      color: #fff; /* Warna ikon putih */
      font-size: 20px; /* Ukuran font ikon */
    }

    .carousel-control-prev:hover, .carousel-control-next:hover {
      background-color: #0056b3; /* Warna latar belakang tombol saat hover */
      transform: scale(1.05); /* Membesarkan tombol saat hover */
    }

    .carousel-control-prev-icon::before {
      content: '◀'; /* Ikon untuk tombol previous */
    }

    .carousel-control-next-icon::before {
      content: '▶'; /* Ikon untuk tombol next */
    }
    </style>
</head>
<body>
    <div class="sidebar" id="sidebar">
        <h1></h1>
        <a class="fa fa-user-circle" href="view_peserta.php">  Form Pasien</a>
        <a class="fa fa-user-circle" href="view_dokter.php">  Form Dokter</a>
        <a class="fa fa-user-circle" href="form_poli.php">  Form Poli</a>
        <a class="fa fa-user-circle" href="rekam_medis.php">  Form Rekam Medis</a>
        <a class="fa fa-pencil-square-o" href="laporan.php">  Laporan</a>
    </div>

    <div class="content" id="content">
        <header>
            <h1>Klinik Apotik Bunda Aliya</h1>
            <button class="toggle-btn" id="toggleBtn">☰</button>
        </header>
        <main>
            <div class="overview">
                <div class="card">
                    <h2>Jumlah Pasien</h2>
                    <p id="patientCount"><?php echo $peserta; ?></p>
                </div>
                <div class="card">
                    <h2>Jumlah Dokter</h2>
                    <p id="doctorCount"><?php echo $bidan; ?></p>
                </div>
                <div class="card">
                    <h2>Jumlah Poli</h2>
                    <p id="poliCount"><?php echo $poli; ?></p>
                </div>
            </div>

            <div class="overview">
                <div class="container">
                <div id="carouselExampleDark" class="carousel carousel-dark slide">
                    <div class="carousel-indicators">
                        <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                        <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
                        <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
                    </div>
                    <div class="carousel-inner">
                        <div class="carousel-item active" data-bs-interval="10000">
                        <img src="images/1.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block text-white tp">
                            <h5>First slide label</h5>
                            <p>Some representative placeholder content for the first slide.</p>
                        </div>
                        </div>
                        <div class="carousel-item" data-bs-interval="2000">
                        <img src="images/2.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block text-white tp">
                            <h5>Second slide label</h5>
                            <p>Some representative placeholder content for the second slide.</p>
                        </div>
                        </div>
                        <div class="carousel-item">
                        <img src="images/3.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block text-white tp">
                            <h5>Third slide label</h5>
                            <p>Some representative placeholder content for the third slide.</p>
                        </div>
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                    </div>
                 </div>
            </div>
        </main>
    </div>

    <script>
        document.getElementById('toggleBtn').addEventListener('click', function() {
            var sidebar = document.getElementById('sidebar');
            var content = document.getElementById('content');
            var toggleBtn = document.getElementById('toggleBtn');

            if (sidebar.classList.contains('hidden')) {
                sidebar.classList.remove('hidden');
                content.classList.remove('expanded');
                toggleBtn.style.left = '0px'; // Posisi tombol di samping sidebar
                toggleBtn.style.top = '45px'; // Posisi tombol di samping sidebar
            } else {
                sidebar.classList.add('hidden');
                content.classList.add('expanded');
                toggleBtn.style.left = '0'; // Posisi tombol ketika sidebar disembunyikan
            }
        });
    </script>
</body>
</html>
