<?php
include 'db.php';

if (isset($_GET['no_transaksi'])) {
    $noTransaksi = $conn->real_escape_string($_GET['no_transaksi']);
    
    // Query untuk menghapus data
    $sql = "DELETE FROM TrekamMedis WHERE No_Transaksi = '$noTransaksi'";

    if ($conn->query($sql) === TRUE) {
        // Mengirim respons sukses
        echo json_encode(['success' => true]);
    } else {
        // Mengirim respons gagal
        echo json_encode(['success' => false, 'message' => $conn->error]);
    }

    $conn->close();
} else {
    // Mengirim respons gagal jika parameter tidak ada
    echo json_encode(['success' => false, 'message' => 'No transaksi tidak ditemukan.']);
}
?>
