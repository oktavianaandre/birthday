<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $no_transaksi = $_POST['no_transaksi'];

    $sql = "DELETE FROM TrekamMedis WHERE No_Transaksi = '$no_transaksi'";

    if ($conn->query($sql) === TRUE) {
        header("Location: rekam_medis.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
