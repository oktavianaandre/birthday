<?php
include 'db.php';

if (isset($_GET['no_transaksi'])) {
    $no_transaksi = $_GET['no_transaksi'];

    $sql = "DELETE FROM TrekamMedis WHERE No_Transaksi = '$no_transaksi'";

    if ($conn->query($sql) === TRUE) {
        header("Location: rekam_medis.php");
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "No transaction number provided.";
}

$conn->close();
?>