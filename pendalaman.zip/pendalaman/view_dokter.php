<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Bidan Klinik Apotik Bunda Aliya</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }

        header {
            background: #333;
            color: #fff;
            padding: 1rem 0;
            text-align: center;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
        }

        .button-container {
            margin-top: 1rem;
            text-align: center;
        }

        .button-container a {
            background: #007bff;
            color: #fff;
            padding: 0.75rem 1.5rem;
            text-decoration: none;
            border-radius: 4px;
            font-size: 1rem;
        }

        .button-container a:hover {
            background: #0056b3;
        }
        .button-container a:hover {
            background: #0056b3;
        }

        .add-new-container {
            text-align: left;
            margin: 20px 0;
        }

        .add-new-container a {
            background: #28a745;
            color: #fff;
            padding: 0.75rem 1rem;
            text-decoration: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>Daftar Bidan Klinik Apotik Bunda Aliya</h1>
        </header>
        <div class="add-new-container">
                <a href="form_dokter.php">Add New</a>
        </div>
        <main>
            <?php
            include 'db.php';

            $sql = "SELECT b.Nama_Bidan, b.Kode_Poli, p.Nama_Poli
                    FROM Bidan b
                    JOIN Poli p ON b.Kode_Poli = p.Kode_Poli";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo '<table>';
                echo '<tr><th>Nama Bidan</th><th>Nama Poli</th></tr>';
                while ($row = $result->fetch_assoc()) {
                    echo '<tr>';
                    echo '<td>' . $row['Nama_Bidan'] . '</td>';
                    echo '<td>' . $row['Nama_Poli'] . '</td>';
                    echo '</tr>';
                }
                echo '</table>';
            } else {
                echo "<p>No records found.</p>";
            }

            $conn->close();
            ?>
        </main>
    </div>
    <div class="button-container">
            <a href="dashboard.php">Kembali ke Dashboard</a>
        </div>
</body>
</html>
