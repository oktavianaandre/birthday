<?php
include 'db.php';

// Ambil kode peserta dari URL
if (isset($_GET['kode'])) {
    $kode_peserta = $_GET['kode'];

    // Ambil data peserta berdasarkan Kode_Peserta
    $sql = "SELECT * FROM Peserta WHERE Kode_Peserta='$kode_peserta'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    // Pisahkan tanggal lahir menjadi hari, bulan, dan tahun
    $tanggal_lahir = explode("-", $row['Tanggal_Lahir']);
    $tahun_lahir = $tanggal_lahir[0];
    $bulan_lahir = $tanggal_lahir[1];
    $hari_lahir = $tanggal_lahir[2];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_peserta = $_POST['nama_peserta'];
    $tanggal_lahir_hari = $_POST['tanggal_lahir_hari'];
    $tanggal_lahir_bulan = $_POST['tanggal_lahir_bulan'];
    $tanggal_lahir_tahun = $_POST['tanggal_lahir_tahun'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $alamat = $_POST['alamat'];
    $telepon = $_POST['telepon'];
    $email = $_POST['email'];

    // Format tanggal menjadi YYYY-MM-DD
    $tanggal_lahir = $tanggal_lahir_tahun . '-' . $tanggal_lahir_bulan . '-' . str_pad($tanggal_lahir_hari, 2, '0', STR_PAD_LEFT);

    // Update data peserta
    $sql = "UPDATE Peserta 
            SET Nama_Peserta='$nama_peserta', Tanggal_Lahir='$tanggal_lahir', Jenis_Kelamin='$jenis_kelamin', Alamat='$alamat', Telepon='$telepon', Email='$email' 
            WHERE Kode_Peserta='$kode_peserta'";

    if ($conn->query($sql) === TRUE) {
        echo "Data peserta berhasil diperbarui.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Peserta</title>
    <style>
        /* Form Styles */
        form {
            background: #fff;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin: 2rem auto;
            width: 50%;
        }

        form input[type="text"],
        form input[type="email"],
        form input[type="number"],
        form select,
        form textarea {
            width: calc(100% - 2rem);
            padding: 0.5rem;
            margin-bottom: 1rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        form input[type="submit"] {
            background: #333;
            color: #fff;
            border: none;
            padding: 0.75rem;
            border-radius: 4px;
            font-size: 1.2rem;
            cursor: pointer;
            width: 100%;
        }

        form input[type="submit"]:hover {
            background: #555;
        }

        .button-container {
            margin-top: 1rem;
            text-align: center;
        }

        .button-container button {
            background: #007bff;
            color: #fff;
            padding: 0.75rem 1.5rem;
            border-radius: 4px;
            font-size: 1rem;
            cursor: pointer;
            border: none;
        }

        /* Layout for Tanggal Lahir */
        .tanggal-lahir-container {
            display: flex;
            gap: 0.5rem;
            margin-bottom: 1rem;
        }

        .tanggal-lahir-container select,
        .tanggal-lahir-container input[type="number"] {
            flex: 1;
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
    <form id="pesertaForm" method="post" action="">
        Nama Peserta: <input type="text" name="nama_peserta" value="<?php echo $row['Nama_Peserta']; ?>" required><br>

        Tanggal Lahir:
        <div class="tanggal-lahir-container">
            <select name="tanggal_lahir_hari" required>
                <?php
                for ($i = 1; $i <= 31; $i++) {
                    $selected = ($i == (int)$hari_lahir) ? 'selected' : '';
                    echo "<option value=\"$i\" $selected>" . str_pad($i, 2, '0', STR_PAD_LEFT) . "</option>";
                }
                ?>
            </select>
            <select name="tanggal_lahir_bulan" required>
                <?php
                $bulan = [
                    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April',
                    '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus',
                    '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
                ];
                foreach ($bulan as $key => $value) {
                    $selected = ($key == $bulan_lahir) ? 'selected' : '';
                    echo "<option value=\"$key\" $selected>$value</option>";
                }
                ?>
            </select>
            <input type="number" name="tanggal_lahir_tahun" value="<?php echo $tahun_lahir; ?>" placeholder="Tahun" min="1900" max="<?php echo date('Y'); ?>" required>
        </div>

        Jenis Kelamin: 
        <select name="jenis_kelamin" required>
            <option value="Laki-Laki" <?php echo ($row['Jenis_Kelamin'] == 'Laki-Laki') ? 'selected' : ''; ?>>Laki-Laki</option>
            <option value="Perempuan" <?php echo ($row['Jenis_Kelamin'] == 'Perempuan') ? 'selected' : ''; ?>>Perempuan</option>
        </select><br>
        Alamat: <textarea name="alamat" required><?php echo $row['Alamat']; ?></textarea><br>
        Telepon: <input type="text" name="telepon" value="<?php echo $row['Telepon']; ?>" required><br>
        Email: <input type="email" name="email" value="<?php echo $row['Email']; ?>" required><br>
        <input type="submit" value="Update Peserta">
        <div class="button-container">
            <a href="dashboard.php">
                <button type="button">Kembali ke Dashboard</button>
            </a>
        </div>
    </form>

    <script>
        // Add an event listener to handle form submission
        document.getElementById('pesertaForm').addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission

            // Create a FormData object to send form data
            var formData = new FormData(this);

            // Use fetch to send form data to the server
            fetch('edit_peserta.php?kode=<?php echo $kode_peserta; ?>', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                // Show SweetAlert2 success message
                Swal.fire({
                    title: 'Success!',
                    text: 'Data peserta berhasil diperbarui.',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(() => {
                    // Redirect back to the view page
                    window.location.href = 'view_peserta.php';
                });
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    </script>
</body>
</html>

